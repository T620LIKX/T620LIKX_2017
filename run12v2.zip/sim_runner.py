﻿#!/usr/bin/env python3
import csv
import gettinglambdas
import worker_details
import simulator
import helperfunctions as hf
#import company_a as thecompany
import company_b_12 as thecompany
import numpy
import scipy as sp
import scipy.stats
import matplotlib.pyplot as plt
def mean_std(data):
    a = 1.0*numpy.array(data)
    n = len(a)
    m = numpy.mean(a)
    h = numpy.std(a)
    return m, h

days = ['mon','tue','wed','thu','fri','sat','sun']

sim_settings, lambdas, workers = thecompany.initialize_company(days)

iterations = 250
res={}
results = {}
vis=[]
lambdascaling = [0.7,0.75,0.8,0.85,0.9,0.95,1,1.05,1.10,1.15,1.2,1.25,1.3,1.35,1.4,1.45,1.5]
data = []
phonecalls_answered_timely = {}
for scaling in lambdascaling:   
    p2 =[]
    for d in days:

        results[d] = []

        # sensitivity analysis to see the effect of changing lambdas
        tmplambdas = []
        for i in lambdas[d]:
            tmp_i = i.copy()
            tmp_i['lam'] = scaling*tmp_i['lam']
            tmplambdas.append(tmp_i)

        phonecalls_answered_timely[d] = {'within_40': 0, 'within_60': 0, 'within_120': 0, 'within_180': 0}
        total_calls = 0
        p40 = []
        p60 = []
        p120 = []
        p180 = []
        working = []
        av_wait = []
        max_wait = []
        pw = []

        for i in range(iterations):

            stats = simulator.run_simulation(settings_details = sim_settings[d].copy(), lambdas = tmplambdas.copy(), workers_details = workers[d].copy(), SHOWGRAPH=False, SHOWOUTPUT='.') 
            results[d].append(stats) 
        
            phonecalls_answered_timely[d]['within_40'] += stats.count_below_40_sec
            phonecalls_answered_timely[d]['within_60'] += stats.count_below_60_sec
            phonecalls_answered_timely[d]['within_120'] += stats.count_below_120_sec
            phonecalls_answered_timely[d]['within_180'] += stats.count_below_180_sec
            total_calls += stats.number_of_finished_phonecalls
            
            phonecalls_answered_timely[d]['within_40'] = phonecalls_answered_timely[d]['within_40'] / total_calls
            phonecalls_answered_timely[d]['within_60'] = phonecalls_answered_timely[d]['within_60'] / total_calls
            phonecalls_answered_timely[d]['within_120'] = phonecalls_answered_timely[d]['within_120'] / total_calls
            phonecalls_answered_timely[d]['within_180'] = phonecalls_answered_timely[d]['within_180'] / total_calls
            
            p40.append(stats.percentage_below_40_sec)
            p60.append(stats.percentage_below_60_sec)
            p120.append(stats.percentage_below_120_sec)
            p180.append(stats.percentage_below_180_sec)
            working.append(stats.busy)
            if len(pw) < 30000:
                pw.extend(stats.phonecall_length)
        [m1,a1] =mean_std(p40)
        [m2,a2] =mean_std(p60)
        [m3,a3] =mean_std(p120)
        [m4,a4] =mean_std(p180)
        [p1,ep] =mean_std(working)
        p2.append(pw)
        vis.append([scaling,d,m1,a1,m2,a2,m3,a3,m4,a4, p1,ep])
    data.append(p2)
    print('') 
with open('res_run34.csv', 'w',newline='\n',) as myfile:
    fieldname=['scaling','day','mean_40','std_40','mean_60','std_60','mean_120','std_120','mean_180','std_180','Vh_mean','Vh_std','av_wait','av_wait_std','max_wait','max_wait_std']

    wr = csv.writer(myfile)
    wr.writerow(fieldname)
    for i in range(0,len(vis)):
        wr.writerow(vis[i])
'''
print('----------------------------------')
print('lambda, day, within40, within60, within120, within180')
for l in lambdascaling:
    for d in days:
        print('{}; {}; {}; {}; {}; {}'.format(l, d, phonecalls_answered_timely[l][d]['within_40'],phonecalls_answered_timely[l][d]['within_60'],phonecalls_answered_timely[l][d]['within_120'],phonecalls_answered_timely[l][d]['within_180']))
print('----------------------------------')
'''
man= []
tue= []
mid = []
fim = []
fri = []
sat = []
sun = []
xti = []
for i in range(0,len(lambdascaling)):
    xti.append(i+1)
    man.append(data[i][0])
    tue.append(data[i][1])
    mid.append(data[i][2])
    fim.append(data[i][3])
    fri.append(data[i][4])
    sat.append(data[i][5])
    sun.append(data[i][6])


plt.boxplot(man,1, ' ')
plt.title('biðtími á mánudögum')
plt.xticks(xti,lambdascaling)
plt.xlabel('Hlutfall af raun álagi')
plt.ylabel('lengd símtala [mín]')

plt.savefig('boxplot_man.png')

plt.figure()
plt.boxplot(tue,1, ' ')
plt.title('biðtími á Þriðjudögum')
plt.xticks(xti,lambdascaling)
plt.xlabel('Hlutfall af raun álagi')
plt.ylabel('lengd símtala [mín]')
plt.savefig('boxplot_trid.png')
plt.figure()
plt.boxplot(mid,1, ' ')
plt.title('biðtími á miðvikudögum')
plt.xticks(xti,lambdascaling)
plt.xlabel('Hlutfall af raun álagi')
plt.ylabel('lengd símtala [mín]')
plt.savefig('boxplot_mid.png')
plt.figure()
plt.boxplot(fim,1, ' ')
plt.title('biðtími á fimmtudögum')
plt.xticks(xti,lambdascaling)
plt.xlabel('Hlutfall af raun álagi')
plt.ylabel('lengd símtala [mín]')
plt.savefig('boxplot_fim.png')
plt.figure()
plt.boxplot(fri,1, ' ')
plt.title('biðtími á föstudögum')
plt.xticks(xti,lambdascaling)
plt.xlabel('Hlutfall af raun álagi')
plt.ylabel('lengd símtala [mín]')
plt.savefig('boxplot_fos.png')
plt.figure()
plt.boxplot(sat,1, ' ')
plt.title('biðtími á laugardögum')
plt.xticks(xti,lambdascaling)
plt.xlabel('Hlutfall af raun álagi')
plt.ylabel('lengd símtala [mín]')
plt.savefig('boxplot_lau.png')
plt.figure()
plt.boxplot(sun,1, ' ')
plt.title('biðtími á Sunnudögum')
plt.xticks(xti,lambdascaling)
plt.xlabel('Hlutfall af raun álagi')
plt.ylabel('lengd símtala [mín]')
plt.savefig('boxplot_sun.png')
plt.figure()



for j in range(0,len(days)):
    plotscale = []
    wb40= []
    wb40e = []
    wb60 = []
    wb60e = []
    wb120 = []
    wb120e = []
    wb180 = []
    wb180e = []
    p =[]
    pe = []

    for i in range(0,len(vis)):
        if (days[j] == 'mon'):
            day = 'mánudögum'
        elif (days[j] == 'sun'):
            day = 'sunnudögum'
        elif (days[j] == 'thu'):
            day = 'fimmtudögum'
        elif (days[j] == 'tue'):
            day = 'þriðjudögum'
        elif (days[j] == 'fri'):
            day = 'föstudögum'
        elif (days[j] == 'wed'):
            day = 'miðvikudögum'
        elif (days[j] == 'sat'):
            day = 'laugardögum'
        if (vis[i][1] == days[j]):
            plotscale.append(vis[i][0])
            wb40.append(vis[i][2])
            wb40e.append(vis[i][3])
            wb60.append(vis[i][4])
            wb60e.append(vis[i][5])
            wb120.append(vis[i][6])
            wb120e.append(vis[i][7])
            wb180.append(vis[i][8])
            wb180e.append(vis[i][9])
            p.append(vis[i][10])
            pe.append(vis[i][11])


    fig, axs = plt.subplots(2, 2)

    ax= axs[0,0]
    ax.errorbar(plotscale,wb40, yerr=wb40e, fmt='o' )
    ax.set_xlim([lambdascaling[0],lambdascaling[len(lambdascaling)-1]+0.1])
    ax.set_ylim([0,1.1])
    ax.set_title('Undir 40 sek')

    ax = axs[0,1]
    ax.errorbar(plotscale,wb60, yerr = wb60e, fmt='o')
    ax.set_title('Undir 60 sek')
    ax.set_xlim([lambdascaling[0],lambdascaling[len(lambdascaling)-1]+0.1])
    ax.set_ylim([0,1.1])
    ax = axs[1,0]
    ax.errorbar(plotscale,wb120, yerr = wb120e, fmt='o')
    ax.set_title('Undir 120 sek')
    ax.set_xlim([lambdascaling[0],lambdascaling[len(lambdascaling)-1]+0.1])
    ax.set_ylim([0,1.1])   

    ax = axs[1,1]
    ax.errorbar(plotscale,wb180, yerr = wb180e, fmt='o')
    ax.set_title('Undir 180 sek')
    ax.set_xlim([lambdascaling[0],lambdascaling[len(lambdascaling)-1]+0.1])
    ax.set_ylim([0,1.1])
    fig.suptitle('Svarhlutfall á {}'.format(day))
    fig.savefig('Svarhlutfall_a_tima_{}.png'.format(day))
    plt.figure()
    plt.errorbar(plotscale,p, yerr = pe, fmt = 'o')
    plt.title('vinnuhlutfall starfsmanna á {}'.format(day))
    plt.ylabel('hlutfall')
    plt.xlabel('hlutfall af raun álagi')
    plt.xlim([lambdascaling[0],lambdascaling[-1]+0.1])
    plt.ylim(0,1.1)
    plt.savefig('vh_{}.png'.format(day))
    '''
    plt.figure()
    plt.errorbar(plotscale,wait_av, yerr = wait_ave, fmt = 'o' )
    plt.title('Meðalbiðtími miðað við skalað álag á {}'.format(day))
    plt.xlim([lambdascaling[0],lambdascaling[-1]+0.1])
    plt.ylabel('tími [s]')
    plt.xlabel('hlutfall af raun álagi')
    plt.savefig('Mbid_{}'.format(day))
    plt.figure()
    plt.errorbar(plotscale,wait_max, yerr = wait_maxe, fmt= 'o')
    plt.title('Meðal hámarks biðtími miðað við skalað álag á {}'.format(day))
    plt.xlim([lambdascaling[0],lambdascaling[-1]+0.1])
    plt.ylabel('tími [s]')
    plt.xlabel('hlutfall af raun álagi')
    plt.savefig('Maxbid_{}'.format(day))
    plt.figure()
    '''